package org.shokai.soundrecord;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

/*import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.impl.client.DefaultHttpClient;*/

import android.app.Activity;
import android.content.res.Resources;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Main extends Activity implements OnClickListener, OnCompletionListener{
    
    private Button buttonRecord, buttonPlay, buttonUpload;
    private EditText editTextAPI;
    private MediaRecorder recorder;
    private String fileName = "test";
    private File dataDir,fiche;
    String taille,taille2;
    //private File son = new File("son.3gp");
    private String nomFichier = "son";
    private String audio = "audio";
    private DataOutputStream fluxSon;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        trace("start");

        this.dataDir = new File(Environment.getExternalStorageDirectory(), this.getPackageName());
        dataDir.mkdirs();
        //this.son = new File(Environment.getExternalStorageDirectory(), this.getPackageName());
        //son.mkdirs();
        
        buttonRecord = (Button)findViewById(R.id.ButtonRecord);
        buttonRecord.setOnClickListener(this);
        buttonPlay = (Button)findViewById(R.id.ButtonPlay);
        buttonPlay.setOnClickListener(this);
        buttonUpload = (Button)findViewById(R.id.ButtonUpload);
        buttonUpload.setOnClickListener(this);
        
        editTextAPI = (EditText)findViewById(R.id.EditTextAPI);
    }

    public void onClick(View arg0) {
        switch(arg0.getId()){
        case R.id.ButtonRecord:
            if(recorder == null){
                trace("start record");
                try{
                    this.recorder = new MediaRecorder();
                    this.recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    this.recorder.setOutputFormat(MediaRecorder.OutputFormat.AMR_NB);
                    this.recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                    
                    this.recorder.setOutputFile(new File(dataDir, fileName).getAbsolutePath());
                    this.recorder.prepare();
                    this.recorder.start();
                    this.buttonRecord.setText(R.string.button_record_stop);
                }
                catch(Exception e){
                    e.printStackTrace();
                    error(e.toString());
                }
            }
            else{
                trace("stop record");
                try{
                    this.recorder.stop();
                    this.recorder.release();
                    this.recorder = null;
                    this.buttonRecord.setText(R.string.button_record);
                }
                catch(Exception e){
                    e.printStackTrace();
                    error(e.toString());
                }
            }
            break;
        case R.id.ButtonPlay:
            trace("play");
            try{
                MediaPlayer player = new MediaPlayer();
                player.setDataSource(new File(dataDir, fileName).getAbsolutePath());
                player.prepare();
                player.seekTo(0);
                player.start();
                String mot = afficheUltraRapide(new File(dataDir, fileName).getAbsolutePath());
                int t = mot.length();
                String taille = Integer.toString(t);
                System.out.println(dataDir.getAbsolutePath());
                Toast.makeText(getApplicationContext(), taille ,Toast.LENGTH_SHORT).show();
                //System.out.println(mot);
                player.setOnCompletionListener(this);
            }
            catch(Exception e){
                e.printStackTrace();
                error(e.toString());
            }
            break;
        case R.id.ButtonUpload:
            trace("upload");
            try{
                upload();
            }
            catch(Exception e){
                e.printStackTrace();
                error(e.toString());
            }
        }
    }
    public static String afficheUltraRapide(String nomFichier) {
        String retour;
        try{
            File f = new File(nomFichier);
            byte[] buffer = new byte[(int)f.length()];
            DataInputStream in = new DataInputStream(new FileInputStream(f));
            in.readFully(buffer);
            //System.out.println(in);
            for(int i=0;i<buffer.length;i++)
            System.out.println(buffer[i]);
            System.out.println(buffer.length);
            in.close();
            retour = new String(buffer);
            return retour;
        } catch (FileNotFoundException e) {
            System.out.println("Impossible de lire le fichier "+nomFichier+" ! " +e);
            return "";
        } catch (IOException e) {
            System.out.println("Erreur de lecture !" +e);
            return "";
        }
    }
    //Converting a string of hex character to bytes
    public static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2){
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i+1), 16));
        }
        return data;
    }

    //Converting a bytes array to string of hex character
    public static String byteArrayToHexString(byte[] b) {
        int len = b.length;
        String data = new String();

        for (int i = 0; i < len; i++){
            data += Integer.toHexString((b[i] >> 4) & 0xf);
            data += Integer.toHexString(b[i] & 0xf);
        }
        return data;
    }
    public void upload() throws IOException{
        try{
            //try get son
            File f = new File(new File(dataDir, fileName).getAbsolutePath());
            byte[] buffer1 = new byte[(int)f.length()];
            FileInputStream readFile = new FileInputStream (new File(dataDir, fileName).getAbsolutePath());
            readFile.read(buffer1);
            readFile.close();
            String sound = byteArrayToHexString(buffer1);
            String mot = new String(buffer1);
            int t = mot.length();
            taille = Integer.toString(t);
            FileOutputStream fichier2 = openFileOutput(nomFichier,getApplicationContext().MODE_PRIVATE);
            fichier2.write(hexStringToByteArray(sound));
            fichier2.close();
            fiche = getFileStreamPath(nomFichier);
            String texto = fiche.getAbsolutePath();
            byte[] buffer2 = new byte[(int)f.length()];
            FileInputStream readFile2 = new FileInputStream (new File(texto));
            readFile2.read(buffer2);
           Toast.makeText(getApplicationContext(), sound ,Toast.LENGTH_SHORT).show();
           try{
                MediaPlayer player = new MediaPlayer();
                player.setDataSource(fiche.getAbsolutePath());
                player.prepare();
                player.seekTo(0);
                player.start();
                player.setOnCompletionListener(this);
            }
            catch(Exception e){
                e.printStackTrace();
                error(e.toString());
            }
        }
        catch(Exception e){
            throw e;
        }
    }

    public void trace(String message){
        Resources res = getResources();
        Log.v(res.getString(R.string.app_name), message);
    }
    
    public void error(String message){
        Resources res = getResources();
        Log.e(res.getString(R.string.app_name), message);
    }

    public void onCompletion(MediaPlayer mp) {
        mp.stop();
        mp.setOnCompletionListener(null);
        mp.release();
        mp = null;
    }

}
